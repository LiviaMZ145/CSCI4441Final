<!--Root component-->
<template>
  <div class = "app-container">
    <h1>Museum Collection</h1>

    <!-- Search bar -->
    <input
      type="text"
      v-model="searchQuery"
      placeholder="Search the collections..."
      class = "search-bar"
    />

    <!-- Museum items -->
    <div class="items-container">
      <MuseumItem
        v-for="item in filteredItems"
        :key="item._id.$oid"
        :item="item"
      />
    </div>

    <p v-if="!filteredItems.length">No items found.</p>
  </div>
</template>

<script>
import MuseumItem from './components/MuseumItem.vue'; // Child component

export default {
  name: 'App',
  components: { MuseumItem },
  data() {
    return {
      items: [],        // Store museum objects
      searchQuery: ''   // Search input
    };
  },
  computed: {
    filteredItems() {
    const q = (this.searchQuery || "").trim().toLowerCase(); 
    if (!q) return this.items;

    return this.items.filter(item => {
      const fields = [
        item.title,
        item.collection,
        item.origin,
        item.accessionNum,
        item.objectType
      ];

      return fields.some(field =>
        String(field || "").toLowerCase().includes(q)
      );
    });
  }
  },

  async created() {
    // Fetch objects from teh API
    try {
      const response = await fetch('http://localhost:3000/api/objects'); 
      const data = await response.json();
      this.items = data;
    } catch (err) {
      console.error('Error fetching items:', err);
    }
  }
};
</script>

<style>
  /* Global container */
  .app-container {
    max-width: 900px;
    margin: 0 auto;
    padding: 20px;
    font-family: Arial, sans-serif;
  }

  /* Page title */
  h1 {
    text-align: center;
    color: #513B56;
    margin-bottom: 20px;
  }

  /* Search bar */
  .search-bar {
    width: 100%;
    max-width: 400px;
    padding: 10px;
    margin: 0 auto 20px auto;
    display: block;
    border-radius: 5px;
    border: 1px solid #363636;
  }

  /* Container for cards */
  .items-container {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }
</style>