// Import core dependencies
import express from "express";
import cors from "cors";
import { getDB } from "./db.js";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ----------------------
// Middleware
// ----------------------
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ----------------------
// API Routes
// ----------------------
app.get("/api/objects", async (req, res) => {
  try {
    const db = await getDB();
    const items = await db.collection("Catalog").find().toArray();
    res.json(items);
  } catch (err) {
    console.error("Error fetching items:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ----------------------
// Frontend Routes (manual)
// ----------------------

// Root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Museum page
app.get('/museum', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// About page
app.get('/about', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// 404 page
app.get('/404', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// ----------------------
// Start the Server
// ----------------------
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});