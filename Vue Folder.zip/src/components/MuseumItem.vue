<template>
  <div class="museum-item">
    <img
      :src="item.imageURL"
      :alt="item.title"
      class="item-img"
    />

    <div class="details">
      <h3>{{ item.title }}</h3>
      <p><strong>Accession Number:</strong> {{ item.accessionNum }}</p>
      <p><strong>Collection:</strong> {{ item.collection }}</p>
      <p><strong>Object Type:</strong> {{ item.objectType }}</p>
      <p><strong>Medium:</strong> {{ item.medium_Technique }}</p>
      <p><strong>Origin:</strong> {{ item.origin }}</p>
      <p><strong>Period:</strong> {{ item.period }}</p>
      <p><strong>On Display:</strong> {{ item.onShow ? 'Yes' : 'No' }}</p>
    </div>
  </div>
</template>

<script>
  
export default {
  name: 'MuseumItem',
  props: {
    item: Object
  }
};
</script>

<style scoped>
:root {
  --lime-cream: #BCE784;
  --emerald: #5DD39E;
  --vintage-grape: #513B56;
  --graphite: #363636;
  --lavender-grey: #9899A6;
}

.museum-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 16px;
  border-radius: 12px;
  background-color: var(--lime-cream);
  border: 2px solid var(--emerald);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
}

.item-img {
  width: 120px;
  height: auto;
  object-fit: cover;
  border-radius: 8px;
  border: 2px solid var(--vintage-grape);
}

.details {
  flex: 1;
  color: var(--graphite)
}

.details h3 {
  margin: 0 0 8px 0;
  color: var(--vintage-grape);
}

.details p {
  margin: 4px 0;
  color: var(--lavender-grey);
  font-size: 0.95rem;
}


</style>